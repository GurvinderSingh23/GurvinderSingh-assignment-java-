package com.yash.main;

public class ArrayString {
	public String StringConcate(String[] str) {

		String temp = "";
		// String [] str = {"apple","orange","banana","lemon"};
		for (String array : str) {
			temp = temp + array + "-";
		}
		String data = temp.substring(0, temp.length() - 1);
		System.out.println(data);

		return data.toLowerCase();
	}

}
