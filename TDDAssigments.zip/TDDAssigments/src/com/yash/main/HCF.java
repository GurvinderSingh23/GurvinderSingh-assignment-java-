//Write a Junit test in which you will take two numbers and you will test that HCF of two numbers are come to same or not
package com.yash.main;

public class HCF 
{
	public int findHCF(int num1,int num2)
	{
		int hcf=0;

	    for (int i = 1; i <= num1 || i <= num2; i++)
	      {
	          if(num1 % i == 0 && num2 % i == 0) 
	          {
	              hcf = i;
	         }
	      }
		return hcf;
	}
}
