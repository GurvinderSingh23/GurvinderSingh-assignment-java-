package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.yash.main.HCF;

public class HCFTest {

	@Test
	public void test() 
	{
		HCF main = new HCF();
		int num1 = 36;
		int num2 = 60;
		
		int expected = 12;
		
		int actual = main.findHCF(num1, num2);
		assertEquals(expected,actual);
	}
	
	
	

}
