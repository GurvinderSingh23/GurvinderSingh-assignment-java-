package com.yash.test;

import static org.junit.Assert.*;
import static org.fest.assertions.Assertions.assertThat;
import org.junit.Test;

import com.yash.main.Armstrong;


class ArmstrongTest {

	@Test
	public void _153IsValidThreeDigitArmstrongNumber() {
		boolean valid = new Armstrong().isValid(153);

		assertThat(valid).isTrue();
	}

	@Test
	public void _1634IsValidFourDigitArmstrongNumber() {
		boolean valid = new Armstrong().isValid(1634);

		assertThat(valid).isTrue();
	}

	@Test
	public void _370IsValidThreeDigitArmstrongNumber() {
		boolean valid = new Armstrong().isValid(370);

		assertThat(valid).isTrue();
	}

	@Test
	public void _371IsValidThreeDigitArmstrongNumber() {
		boolean valid = new Armstrong().isValid(371);

		assertThat(valid).isTrue();
	}

	@Test
	public void _407IsValidThreeDigitArmstrongNumber() {
		boolean valid = new Armstrong().isValid(407);

		assertThat(valid).isTrue();
	}

	@Test
	public void _8208IsValidFourDigitArmstrongNumber() {
		boolean valid = new Armstrong().isValid(8208);

		assertThat(valid).isTrue();
	}

}
