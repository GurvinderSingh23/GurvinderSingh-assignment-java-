package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import com.yash.main.ContainsEvenOdd;

class ContainsEvenOddTest {

	@Test
	public void testOddNumbersExterminatorNormalList() {
	    //Given
		ContainsEvenOdd	oddNumbersExterminator = new ContainsEvenOdd();
	    ArrayList<Integer> normalList = new ArrayList<Integer>();
	    normalList.add(1);
	    normalList.add(2);
	    normalList.add(3);
	    normalList.add(4);
	    normalList.add(5);
	    normalList.add(6);
}

}
