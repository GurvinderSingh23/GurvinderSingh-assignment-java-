package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.Assert.*;
import org.junit.Test;
import com.yash.main.Singleton;

import junit.framework.Assert;

public class SingletonTest {
	@Test
	public void TestSingletonObject() {

		Singleton instance1 = Singleton.INSTANCE;
		Singleton instance2 = Singleton.INSTANCE;
		// Passes
		Assert.assertSame("Both objects are same", instance1, instance2);
	}

	@Test
	public void TestgetInstance() {

		Singleton instance1 = Singleton.INSTANCE;
		Singleton instance2 = Singleton.INSTANCE;
		// Does not pass
		Assert.assertSame(instance1.getInstance('o'), instance2.getInstance('o'));
	}
}
