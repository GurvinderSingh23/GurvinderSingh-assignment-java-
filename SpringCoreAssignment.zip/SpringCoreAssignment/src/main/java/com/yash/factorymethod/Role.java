package com.yash.factorymethod;

public interface Role {
	void role();

}
