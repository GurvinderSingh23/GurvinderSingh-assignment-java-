package com.yash.mergetwoarray;

import java.util.Arrays;

public class Array1 {

	int[] array1;

	public int[] getArray1() {
		return array1;
	}

	public void setArray1(int[] array1) {
		this.array1 = array1;
	}

	@Override
	public String toString() {
		return "Array1 "+array1[1];
	}
	

}
