package com.yash.mergetwoarray;

public class Array2 {
	int[] array2;

	public int[] getArray2() {
		return array2;
	}

	public void setArray2(int[] array2) {
		this.array2 = array2;
	}

}
