//5. WAP to find the maximum length of given string without using any length function use stream API 
package com.yash.question1;

import java.util.Optional;

public class MaximunLengthOfString {
	int i=0;
	public static void main(String args[]) {
		MaximunLengthOfString mx=new MaximunLengthOfString();
		String str="Gurvinder";
//		
//		Optional<String> strOptional=Optional.ofNullable(str);
//		strOptional.
//		System.out.println(mx.i);

	}

	
}
