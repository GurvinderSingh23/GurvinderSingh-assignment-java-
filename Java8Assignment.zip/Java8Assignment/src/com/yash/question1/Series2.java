package com.yash.question1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Series2 {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1,2,3,6,7,8,10,11,12,13,14,17,18,19,20);
//		list.stream().noneMatch((e1,e2)->e1+1==e2);

		
	}

}
